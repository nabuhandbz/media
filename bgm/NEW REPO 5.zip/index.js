/* Copyright (C) 2021 Abu Ser

Licensed under the  GPL-3.0 License;
you may not use this file except in compliance with the License.

 Abu ser
*/

const chalk = require('chalk');
const {WAConnection, MessageOptions, MessageType, Mimetype, Presence} = require('@adiwajshing/baileys');
const fs = require('fs');
async function whatsAsena() {
  const conn = new WAConnection();
  conn.logger.level = 'warn';
  conn.version = [2,2142,12]
  conn.browserDescription = ["Abu ser", "Safari", '1.0.0']
  const rows = [
 {title: 'ᴏᴡɴᴇʀ ɴᴜᴍʙᴇʀ:-', description: "\n\n*https://wa.me/917025994178*", rowId:"wd1"},
 {title: 'ᴡʜᴀᴛsᴀᴘʟ ɢʀᴏᴜᴘ:-', description: "\n\n*https://chat.whatsapp.com/Bq0eHs3UpGJ2BKIHOmy7mk*", rowId:"wd2"},
 {title: 'ʏᴏᴜᴛʜᴜʙᴇ ᴄʜᴀɴɴᴇʟ:-', description: "\n\n*https://youtube.com/channel/UCWroqii8PORgNBdZO5MG6Fw*", rowId:"wd3"}
]

const sections = [{title: "ᴄʟɪᴄᴋ ʜᴇʀᴇ ᴛʜɪs", rows: rows}]

const button = {
 buttonText: '« ᴄʟɪᴄᴋ ʜᴇʀᴇ ᴛʜɪs!',
 description: "*ᴀʙᴜ sᴇʀ ʙᴏᴛ*\n\n ```ʏᴏᴜʀ ʜᴀᴘᴘʏ ɪs ᴍʏ ʜᴀᴘᴘʏ```",
 sections: sections,
 listType: 1
}


  conn.on('connecting', async () => {
    console.log(`${chalk.green.bold('Afx-Abu ')}${chalk.green.bold('-Abu')}
${chalk.white.italic('AbuString code recipient')}
${chalk.blue.bold('ℹ️  Connecting Abu... Please wait.')}`);
  });

  conn.on('open', async () => { 
    console.log(
      chalk.green.bold('ABU QR CODE: '),
      'ᴀʙᴜ sᴇʀ;;;' +
      Buffer.from(JSON.stringify(conn.base64EncodedAuthInfo())).toString(
        'base64'
      )
    );
    await conn.sendMessage(
      conn.user.jid,
      'ᴀʙᴜ sᴇʀ;;;' +
      Buffer.from(JSON.stringify(conn.base64EncodedAuthInfo())).toString(
        'base64'
      ),
      MessageType.text
    );
    if (conn.user.jid.startsWith('91')) {
      await conn.sendMessage(
        conn.user.jid,
        '*~___________~* *'+ conn.user.name + ' ~___________~*\n\n*▪️ ᴀʙᴜ sᴇʀ sᴜᴄᴄᴇssғᴜʟʟʏ sᴄᴀɴᴇᴅ✅️*\n*▪️ᴛʜᴀɴᴋs ғᴏʀ ᴜsɪɴɢ ᴀʙᴜ sᴇʀ ʙᴏᴛ ❤️*',
        MessageType.text
      );
      await conn.sendMessage(
        conn.user.jid, fs.readFileSync("./bott.mp3"), MessageType.audio, { mimetype: Mimetype.mp4Audio, ptt: true});
        await conn.sendMessage( conn.user.jid, button, MessageType.listMessage);
        await conn.sendMessage(
        conn.user.jid,
        '*~___________~* *'+ conn.user.name + ' ~___________~*\n\n*THIS IS ANNOUNCEMENT MESSAGE*\n\n*THERE WILL BE NO REPLY FROM MY OWNWER FOR MONDAY-FRIDAY BECAUSE OF BUSY IN CLASS* \n\n *YOU CAN REPORT BUGS & ERRORS IN OFFICIAL BOT GROUP[ https://chat.whatsapp.com/Bq0eHs3UpGJ2BKIHOmy7mk ]* \n*FOR ALL BOT SUPPORT* \n *YOU SHOULD MENTION ME IN THIS GROUP OR SAY THE NAME OF BOT.......*\n\n\n\n           --- *BOT OWNER*',
        MessageType.text
      );
    } else {
      await conn.sendMessage(
        conn.user.jid,
        '*~__~* *'+ conn.user.name + ' ~__~*\n\n*▪️ ᴀʙᴜ sᴇʀ sᴜᴄᴄᴇssғᴜʟʟʏ sᴄᴀɴᴇᴅ✅️*\n*▪️ᴛʜᴀɴᴋs ғᴏʀ ᴜsɪɴɢ ᴀʙᴜ sᴇʀ ʙᴏᴛ ❤️*',
        MessageType.text
      );
      await conn.sendMessage(
        conn.user.jid, fs.readFileSync("./bott.mp3"), MessageType.audio, { mimetype: Mimetype.mp4Audio, ptt: true});
        await conn.sendMessage( conn.user.jid, button, MessageType.listMessage);
        await conn.sendMessage(
        conn.user.jid,
        '*~__~* *'+ conn.user.name + ' ~__~*\n\n*THIS IS ANNOUNCEMENT MESSAGE*\n\n*THERE WILL BE NO REPLY FROM MY OWNWER FOR MONDAY-FRIDAY BECAUSE OF BUSY IN CLASS* \n\n *YOU CAN REPORT BUGS & ERRORS IN OFFICIAL BOT GROUP[ https://chat.whatsapp.com/Bq0eHs3UpGJ2BKIHOmy7mk ]* \n*FOR BOT SUPPORT* \n *YOU SHOULD MENTION ME IN THIS GROUP OR SAY THE NAME OF BOT.......*\n\n\n\n            *BOT OWNER*',
        MessageType.text
      );
    }
    console.log(
      chalk.green.bold(
        "\n\n Nigalkku sandesham pakarthan \n kaliyunnillegil,whatsapp parishodikkuka \n nigalude numberillekku  code ayachinnu!\n\n\n\n"
      ),
      chalk.green.bold(
        'IF YOU CANNOT COPY THE MESSAGE, PLEASE CHECK WHATSAPP. QR CODE SENT TO YOUR OWN NUMBER!'
      )
    );
    process.exit(0);
  });

  await conn.connect();
}

whatsAsena();
